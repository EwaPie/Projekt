package com.projekt.enums;

public enum TypRachunku {
    PARAGON, FAKTURA
}
