//
// Created by User on 2019-01-16.
//
#pragma once


enum ReportType {
    COST, INCOME, BALANCE
};

